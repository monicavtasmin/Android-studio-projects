package com.example.expensemanager;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Chronometer stopWatch;
    boolean time;
    // https://developer.android.com/reference/java/lang/Long, accessed 5 Apr 2022
    long pauseTimer;

    // to display and save user tasks and stopwatch
    TextView displayTask;
    SharedPreferences sharedPreferences;
    EditText userTask;
    String TASK_NAME;
    ImageView stopButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        displayTask = findViewById(R.id.displayTask);
        userTask = findViewById(R.id.userTask);
        stopWatch = findViewById(R.id.stopWatch);
        stopButton = findViewById(R.id.stopButton);
        displayTask.setText("You spent ... on ... last time");

        // https://stackoverflow.com/questions/32079320/android-chronometer-save-time, accessed 14 Apr
        if (savedInstanceState !=null)
        {

            time = savedInstanceState.getBoolean("running");
            if(time) {
                stopWatch.setBase(savedInstanceState.getLong("ChronoTime"));
                stopWatch.start();
            }
            else {
                stopWatch.setBase(SystemClock.elapsedRealtime() - savedInstanceState.getLong("ChronoTime"));
            }

        }
        stopButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String userTaskText = userTask.getText().toString();
                if (userTaskText.equals("")){
                    Toast toast = Toast.makeText(getApplicationContext(), "Please enter a task", Toast.LENGTH_SHORT);
                    toast.show();
                }
                else
                {
                    if (time)
                    {
                        stopWatch.stop();
                        // time difference displayed by chronometer
                        // to stop the chronometer, not only the text
                        pauseTimer = SystemClock.elapsedRealtime() - stopWatch.getBase();
                        time = false;
                    }
                    String timeTaken = stopWatch.getText().toString();
                    displayTask.setText("You spent " + timeTaken + " on " + userTask.getText().toString() + " last time");
                    taskUser();
                }
            }
        });
        checkSharedPreferences();

    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        if(time) {
            outState.putLong("ChronoTime", stopWatch.getBase());
        }
        else {
            outState.putLong("ChronoTime", pauseTimer);
        }
        outState.putBoolean("running", time);
    }

    public void taskUser() {
        sharedPreferences = getSharedPreferences("com.example.myapplication", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(TASK_NAME, displayTask.getText().toString());
        editor.apply();
    }

    public void checkSharedPreferences() {
        sharedPreferences = getSharedPreferences("com.example.myapplication", MODE_PRIVATE);
        String text = sharedPreferences.getString(TASK_NAME, "");
        displayTask.setText(text);
    }

    public void startTime(View view){
        // if the time doesn't run, start the chronometer
        if (!time){
            time = true;
            // so that the chronometer will start from 0
            // https://developer.android.com/reference/android/widget/Chronometer, accessed 5 Apr 2022
            stopWatch.setBase(SystemClock.elapsedRealtime());
            stopWatch.setBase(SystemClock.elapsedRealtime() - pauseTimer);
            stopWatch.start();
        }
    }

    public void pauseTime(View view){
        if (time){
            stopWatch.stop();
            // time difference displayed by chronometer
            // to stop the chronometer, not only the text
            pauseTimer = SystemClock.elapsedRealtime() - stopWatch.getBase();
            time = false;
        }
    }
}
