package com.example.unitconvertermobileapp;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;

import static java.lang.Integer.parseInt;

import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

//public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
public class MainActivity extends AppCompatActivity{

    // declaration
    // user input
    EditText userInput;
    TextView result1, result2, result3, unitcm, unitft, unitinc;

    // meter
    ImageView meterButton;

    // temperature
    ImageView termoButton;

    // weight
    ImageView weightButton;

//    private Spinner optionSpinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // initialization
        userInput = findViewById(R.id.userInput);
        result1 = findViewById(R.id.result1);
        result2 = findViewById(R.id.result2);
        result3 = findViewById(R.id.result3);
        unitcm = findViewById(R.id.unitcm);
        unitft = findViewById(R.id.unitft);
        unitinc = findViewById(R.id.unitinc);
        meterButton = findViewById(R.id.meterButton);
        termoButton = findViewById(R.id.termoButton);
        weightButton = findViewById(R.id.weightButton);

        // source: Android Studio developers
        // https://developer.android.com/guide/topics/ui/controls/spinner
        Spinner optionSpinner = (Spinner) findViewById(R.id.optionSpinner);
        // creating ArrayAdapter using string array (import array adapter too)
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.options, android.R.layout.simple_spinner_dropdown_item);
        // Specify layout
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // applying adapter to spinner
        optionSpinner.setAdapter(adapter);

        //on-click event for each button
        //meter button
        meterButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // only calls the MetreConverter function if the user chooses corresponding spinner and button
                if (optionSpinner.getSelectedItem().toString().equals("Metre"))
                {
                    MetreConverter();
                }
                else
                // pops up error message if the user chooses wrong button
                {
                    Toast toast = Toast.makeText(getApplicationContext(), "WRONG BUTTON. PLEASE TRY AGAIN", Toast.LENGTH_SHORT);
                    toast.show();
                }
            }
        });

        // temperature button
        termoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // only calls the TemperatureConverter function if the user chooses corresponding spinner and button
                if (optionSpinner.getSelectedItem().toString().equals("Celcius"))
                {
                    TemperatureConverter();
                }
                else
                // pops up error message if the user chooses wrong button
                {
                    Toast toast = Toast.makeText(getApplicationContext(), "WRONG BUTTON. PLEASE TRY AGAIN", Toast.LENGTH_SHORT);
                    toast.show();
                }
            }
        });

        // weight button
        weightButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // only calls the WeightConverter function if the user chooses corresponding spinner and button
                if (optionSpinner.getSelectedItem().toString().equals("Kilogram"))
                {
                    WeightConverter();
                }
                // pops up error message if the user chooses wrong button
                else
                {
                    Toast toast = Toast.makeText(getApplicationContext(), "WRONG BUTTON. PLEASE TRY AGAIN", Toast.LENGTH_SHORT);
                    toast.show();
                }
            }
        });
    }

    // Responding to User Selections
    // https://developer.android.com/guide/topics/ui/controls/spinner
    public class SpinnerActivity extends Activity implements AdapterView.OnItemSelectedListener
    {
        public void onItemSelected(AdapterView<?> parent, View view, int pos, long id)
        {
            // Retrieve selected item
             parent.getItemAtPosition(pos);
        }
        public void onNothingSelected(AdapterView<?> parent)
        {
            // Another interface callback
        }
    }

    private void MetreConverter()
    {
        String valueEntered = userInput.getText().toString();
        double metre = Double.parseDouble(valueEntered);

        // if the user enters a negative value, this will pop out to notfity user to only enter positive values
        if (metre < 0) {
            Toast toast = Toast.makeText(getApplicationContext(), "please enter a positive value", Toast.LENGTH_SHORT);
            toast.show();
        }

        //execute and displays the conversion if the user enters a postive value
        else {
            // metre to cm conversion,
            double cm = metre * 100;

            // metre to ft conversion,
            double ft = metre * 3.28084;

            // metre to ft conversion,
            double inch = metre * 39.3701;

            // 2 decimal points
            // shows the units
            result1.setText(String.format("%.2f", cm));
            unitcm.setText("Centimetre");
            result2.setText(String.format("%.2f", ft));
            unitft.setText("Foot");
            result3.setText(String.format("%.2f", inch));
            unitinc.setText("Inch");
        }
    }

    // execute and displays the conversion even if the user enters negative value since temperature can be negative
    private void TemperatureConverter()
    {
        String valueEntered = userInput.getText().toString();
        double celcius = Double.parseDouble(valueEntered);

        // celcius to g fahrenheit
        double far = (celcius * 9/5) + 32;

        // kg to ounce
        double kelvin = celcius +  273.15;

        // 2 decimal points
        // shows the units
        result1.setText(String.format("%.2f", far));
        unitcm.setText("ºF");
        result2.setText(String.format("%.2f", kelvin));
        unitft.setText("ºK");
        result3.setText("");
        unitinc.setText("");
    }

    private void WeightConverter()
    {
        String valueEntered = userInput.getText().toString();
        double kg = Double.parseDouble(valueEntered);

        // if the user enters a negative value, this will pop out to notfity user to only enter positive values since mass can't be negative
        if (kg < 0)
        {
            Toast toast = Toast.makeText(getApplicationContext(), "please enter a positive value", Toast.LENGTH_SHORT);
            toast.show();
        }

        // execute and displays the conversion if the user enters a postive value
        else {
            // kg to g
            double g = (kg * 1000);

            // kg to ounce
            double ounce = (kg * 35.274);

            // kg to pound
            double pound = (kg * 2.20462);

            // 2 decimal points
            // shows the units
            result1.setText(String.format("%.2f", g));
            unitcm.setText("Gram");
            result2.setText(String.format("%.2f", ounce));
            unitft.setText("Ounce(oz)");
            result3.setText(String.format("%.2f", pound));
            unitinc.setText("Pound(lb)");
        }
    }
}