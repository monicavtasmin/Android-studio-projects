package com.example.quizapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class YourScore extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_your_score);

        TextView finalScore = findViewById(R.id.finalScore);
        TextView finalName = findViewById(R.id.finalName);
        Button newQuiz = findViewById(R.id.newQuiz);
        Button finishQuiz = findViewById(R.id.finishQuiz);

        // displays username (Congrats (name))
        Intent intentlast = getIntent();
        String name = intentlast.getStringExtra("username");
        finalName.setText(name);

        // displays how many questions are correct
        Integer CorrectAnswer = intentlast.getIntExtra("correct",0);
        finalScore.setText(String.valueOf(CorrectAnswer + " / 5"));

        // take new quiz, go to the 1st page
        newQuiz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //startActivity(new Intent(YourScore.this, MainActivity.class));
                Intent intentname = new Intent(YourScore.this, MainActivity.class);
                intentname.putExtra("username", finalName.getText().toString());
                startActivity(intentname);
            }
        });

        // https://developer.android.com/reference/android/app/Activity , accessed 25/3/2022
        finishQuiz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finishAffinity();
            }
        });
    }

}