package com.example.quizapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

// this is the 2nd page that will appear as the user clicks the START button
public class QuizQuestion1 extends AppCompatActivity
{
    private int CurrentProgress = 1;
    private String userOption;

    // to show username on the last page
    TextView secondTextView;
    String name;
    // declaration
    private TextView QuestionSection;
    private Button FirstChoice, SecondChoice, ThirdChoice, ProceedAnswer;
    // https://stackoverflow.com/questions/12321177/arraylist-or-list-declaration-in-java; accessed 1 Apr 2022
    private ArrayList<QuizData> quizDataArrayList;

    // count function for progress bar
    TextView progressCount;
    Button ProceedButton;
    int Count = 1;

    // progress bar
    private ProgressBar progressBar;

    int myscore = 0, questionat = 1, currentPos;

//    public void proceedButton (View v){
//        Intent intentlast = new Intent(this, YourScore.class);
//        startActivity(intentlast);
//    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz_question1);

        progressBar = findViewById(R.id.progressBar);
        QuestionSection = findViewById(R.id.QuestionSection);
        FirstChoice = findViewById(R.id.FirstChoice);
        SecondChoice = findViewById(R.id.SecondChoice);
        ThirdChoice = findViewById(R.id.ThirdChoice);
        ProceedAnswer = findViewById(R.id.ProceedButton);
        quizDataArrayList = new ArrayList<>();
        secondTextView = findViewById(R.id.secondTextView);
//        secondTextView.setText(name);

        // count function for progress bar
        progressCount = (TextView) findViewById(R.id.progressCount);
        ProceedAnswer = (Button) findViewById(R.id.ProceedButton);


        getQuestions(quizDataArrayList);
        currentPos = 0;
        setData(currentPos);

        ProceedAnswer.setText("Submit");

        FirstChoice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                FirstChoice.setBackgroundColor(getResources().getColor(R.color.greenbutton));
                FirstChoice.setTextColor(Color.BLACK);
                SecondChoice.setBackgroundColor(Color.WHITE);
                SecondChoice.setTextColor(Color.BLACK);
                ThirdChoice.setBackgroundColor(Color.WHITE);
                ThirdChoice.setTextColor(Color.BLACK);

                userOption = FirstChoice.getText().toString();

            }
        });

        SecondChoice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                SecondChoice.setBackgroundColor(getResources().getColor(R.color.greenbutton));
                SecondChoice.setTextColor(Color.BLACK);
                FirstChoice.setBackgroundColor(Color.WHITE);
                FirstChoice.setTextColor(Color.BLACK);
                ThirdChoice.setBackgroundColor(Color.WHITE);
                ThirdChoice.setTextColor(Color.BLACK);

                userOption = SecondChoice.getText().toString();

            }
        });

        ThirdChoice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                ThirdChoice.setBackgroundColor(getResources().getColor(R.color.greenbutton));
                ThirdChoice.setTextColor(Color.BLACK);
                SecondChoice.setBackgroundColor(Color.WHITE);
                SecondChoice.setTextColor(Color.BLACK);
                FirstChoice.setBackgroundColor(Color.WHITE);
                FirstChoice.setTextColor(Color.BLACK);

                userOption = ThirdChoice.getText().toString();

            }
        });

        // there will be 2 types of buttons to proceed
        ProceedAnswer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String ButtonText = ProceedAnswer.getText().toString();

                // if the user doesn't click any choice, this msg will pop up
                if(userOption.isEmpty()) {
                    Toast.makeText(QuizQuestion1.this,"Please choose an answer",Toast.LENGTH_SHORT).show();
                }
                // "Next" to lock user's final answer
                else if (ButtonText.equals("Submit")) {
                    if (userOption != quizDataArrayList.get(currentPos).getCorrectans()) {
                        if (userOption == FirstChoice.getText().toString()) {
                            FirstChoice.setBackgroundColor(getResources().getColor(R.color.redbutton));
                        } else if (userOption == SecondChoice.getText().toString()) {
                            SecondChoice.setBackgroundColor(getResources().getColor(R.color.redbutton));
                        } else if (userOption == ThirdChoice.getText().toString()) {
                            ThirdChoice.setBackgroundColor(getResources().getColor(R.color.redbutton));
                        }
                    } else {
                        myscore++;
                    }

                    checkCorrectAnswers();

//                    if (userOption == quizDataArrayList.get(currentPos).getCorrectans()) {
//                        myscore++;
//                    }
                    // after showing if the user has entered correct/incorrect answer, user can go to the next question
                    ProceedAnswer.setText("Next");
                }
                else if (ButtonText.equals("Next")) {

                    // other than selected answer, the other buttons will remain white and the text will remain black
                    FirstChoice.setBackgroundColor(Color.WHITE);
                    FirstChoice.setTextColor(Color.BLACK);
                    SecondChoice.setBackgroundColor(Color.WHITE);
                    SecondChoice.setTextColor(Color.BLACK);
                    ThirdChoice.setBackgroundColor(Color.WHITE);
                    ThirdChoice.setTextColor(Color.BLACK);

                    questionat++;
                    currentPos++;
                    userOption = "";

                    // count function for progress bar
                    if (currentPos >= 0){
                        // count function for progress bar
                        Count++;
                        progressCount.setText(String.valueOf(Count + " / 5"));
                        CurrentProgress = CurrentProgress +1;
                        progressBar.setProgress(CurrentProgress);
                        progressBar.setMax(5);
                    }

                    //
                    if (currentPos <= 4) {
                        setData(currentPos);
                        ProceedAnswer.setText("Submit");

                        // accumulate correct ans
                    } else {
                        Intent intentlast = new Intent(QuizQuestion1.this, YourScore.class);
                        intentlast.putExtra("username", secondTextView.getText().toString());
                        intentlast.putExtra("correct", myscore);
                        secondTextView.setText(name);
                        startActivity(intentlast);
                    }

                }
            }
        });


        // define the uncreated TextView that will display username in the QuizQuestion1 page
        TextView secondTextView = findViewById(R.id.secondTextView);
        // get information
        Intent intent = getIntent();
        String name = intent.getStringExtra("username");
        secondTextView.setText(name);
    }

    private void setData(int currentPos){
        QuestionSection.setText(quizDataArrayList.get(currentPos).getQuestion());
        FirstChoice.setText(quizDataArrayList.get(currentPos).getFirstchoice());
        SecondChoice.setText(quizDataArrayList.get(currentPos).getSecondchoice());
        ThirdChoice.setText(quizDataArrayList.get(currentPos).getThirdchoice());
    }
    // adding the Questions, choices, and answers
    private void getQuestions(ArrayList<QuizData> quizDataArrayList) {
        quizDataArrayList.add(new QuizData("What do we use to retrieve the bundle object?","getExtra()","getExtras()","putExtra","getExtras()",""));
        quizDataArrayList.add(new QuizData("What does putExtra() contain?","name and type","value and number","name and value","name and value",""));
        quizDataArrayList.add(new QuizData("What can be used to pop-up message","Intent","Window","Toast","Toast",""));
        quizDataArrayList.add(new QuizData("How do we save our data as we closed the app?","SharedPreferences","Intent","Bundle","SharedPreferences",""));
        quizDataArrayList.add(new QuizData("If the background is still visible, what activity has been carried out?","Destroyed","Paused","Active","Paused",""));
    }

    // Check if the user has entered correct answer
    // if correct, the button color will be green
    // if incorrect, the button color will be red
    private void checkCorrectAnswers() {
        final String getCorrectans = quizDataArrayList.get(currentPos).getCorrectans();
        if (FirstChoice.getText().toString().equals(getCorrectans)) {
            FirstChoice.setBackgroundColor(getResources().getColor(R.color.greenbutton));
        } else if (SecondChoice.getText().toString().equals(getCorrectans)) {
            SecondChoice.setBackgroundColor(getResources().getColor(R.color.greenbutton));
        } else if (ThirdChoice.getText().toString().equals(getCorrectans)) {
            ThirdChoice.setBackgroundColor(getResources().getColor(R.color.greenbutton));
        }
    }

    // checking wrong answers to display
    private void checkWrongAnswers() {
        final String getWrongAnswers = quizDataArrayList.get(currentPos).getCorrectans();
        if (FirstChoice.getText().toString().equals(getWrongAnswers)) {
            FirstChoice.setBackgroundColor(getResources().getColor(R.color.redbutton));
        } else if (SecondChoice.getText().toString().equals(getWrongAnswers)) {
            SecondChoice.setBackgroundColor(getResources().getColor(R.color.redbutton));
        } else if (ThirdChoice.getText().toString().equals(getWrongAnswers)) {
            ThirdChoice.setBackgroundColor(getResources().getColor(R.color.redbutton));
        }
    }
}