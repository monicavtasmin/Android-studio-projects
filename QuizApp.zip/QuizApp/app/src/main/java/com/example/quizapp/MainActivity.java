package com.example.quizapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {
    // define
//    String name;
    EditText userName;
    Button startButton;
    // when the user clicks the START button, they will be redirected to the QuizQuestion1 page
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // set id
        startButton = findViewById(R.id.startButton);
        userName = findViewById(R.id.userName);
        Intent intentname = getIntent();
        if(intentname!=null) {
            String n = intentname.getStringExtra("username");
            userName.setText(n);
        }

    }
    public void startButton (View v)
    {
        //      pops a toast if the user doesn't enter their name
        String userNameText = userName.getText().toString();
        if (userNameText.equals("")){
            Toast toast = Toast.makeText(getApplicationContext(), "Please enter a name", Toast.LENGTH_SHORT);
            toast.show();
        }
        else {
            Intent intent = new Intent(this, QuizQuestion1.class);
            // pass username to the QuizQuestion1 page
            // only if the user enter their name
            intent.putExtra("username", userName.getText().toString());
            startActivity(intent);
            finish();
        }
    }
}