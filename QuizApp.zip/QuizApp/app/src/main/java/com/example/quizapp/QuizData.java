package com.example.quizapp;

// this is what's in the quiz
public class QuizData {
    private String question;
    private String firstchoice;
    private String secondchoice;
    private String thirdchoice;
    private String correctans;
    private String userOption;

    // generate Getter
    public String getQuestion() {
        return question;
    }

    // generate Setter
    public void setQuestion(String question) {
        this.question = question;
    }

    public String getFirstchoice() {
        return firstchoice;
    }

    public void setFirstchoice(String firstchoice) {
        this.firstchoice = firstchoice;
    }

    public String getSecondchoice() {
        return secondchoice;
    }

    public void setSecondchoice(String secondchoice) {
        this.secondchoice = secondchoice;
    }

    public String getThirdchoice() {
        return thirdchoice;
    }

    public void setThirdchoice(String thirdchoice) {
        this.thirdchoice = thirdchoice;
    }

    public String getCorrectans() {
        return correctans;
    }

    public void setCorrectans(String correctans) {
        this.correctans = correctans;
    }

    public String getUserOption() {
        return userOption;
    }

    public void setUserOption(String userOption) {
        this.userOption = userOption;
    }

    // Constructor
    public QuizData(String question, String firstchoice, String secondchoice, String thirdchoice, String correctans, String userOption) {
        this.question = question;
        this.firstchoice = firstchoice;
        this.secondchoice = secondchoice;
        this.thirdchoice = thirdchoice;
        this.correctans = correctans;
        this.userOption = userOption;
    }
}
